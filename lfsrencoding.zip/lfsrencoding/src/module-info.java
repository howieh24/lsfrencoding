/**
 * 
 */
/**
 * @author howie
 *
 */
module lfsrencoding {
}