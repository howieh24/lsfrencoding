package lfsrencoding;

import java.util.Arrays;

public class LFSREncryption {
    private static final int FEEDBACK = 0x87654321;

    public static byte[] crypt(byte[] data, long initialValue) {
        byte[] encryptedData = Arrays.copyOf(data, data.length);
        long lfsr = initialValue;

        for (int i = 0; i < encryptedData.length; i++) {
            byte keyByte = (byte) (lfsr & 0xFF);
            encryptedData[i] ^= keyByte;

            for (int j = 0; j < 8; j++) {
                if ((lfsr & 1) == 0) {
                    lfsr >>>= 1;
                } else {
                    lfsr = (lfsr >>> 1) ^ FEEDBACK;
                }
            }
        }

        return encryptedData;
    }

    public static void main(String[] args) {
        byte[] data = "apple".getBytes();
        long initialValue = 0x12345678;
        byte[] encryptedData = crypt(data, initialValue);

        System.out.println("Encrypted data: " + Arrays.toString(encryptedData));

        // Decrypting the encrypted data to verify the result
        byte[] decryptedData = crypt(encryptedData, initialValue);
        String decryptedString = new String(decryptedData);
        System.out.println("Decrypted data: " + decryptedString);
    }
}