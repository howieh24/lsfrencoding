package fileencoding;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

public class FileEncryption {
	 private static final int FEEDBACK = 0x87654321;
	    private static final long INITIAL_VALUE = 0x4F574154;

	    public static byte[] crypt(byte[] data, long initialValue) {
	        byte[] encryptedData = Arrays.copyOf(data, data.length);
	        long lfsr = initialValue;

	        for (int i = 0; i < encryptedData.length; i++) {
	            byte keyByte = (byte) (lfsr & 0xFF);
	            encryptedData[i] ^= keyByte;

	            for (int j = 0; j < 8; j++) {
	                if ((lfsr & 1) == 0) {
	                    lfsr >>>= 1;
	                } else {
	                    lfsr = (lfsr >>> 1) ^ FEEDBACK;
	                }
	            }
	        }

	        return encryptedData;
	    }

	    public static void main(String[] args) {
	        if (args.length < 1) {
	            System.out.println("Please provide the path to the KDB file.");
	            return;
	        }

	        String kdbFilePath = args[0];
	        Path path = Paths.get(kdbFilePath);

	        try {
	            byte[] encryptedData = Files.readAllBytes(path);
	            byte[] decryptedData = crypt(encryptedData, INITIAL_VALUE);
	            String decodedContent = new String(decryptedData);

	            System.out.println(decodedContent);
	        } catch (IOException e) {
	            System.out.println("An error occurred while reading the KDB file: " + e.getMessage());
	        }
	    }

}
